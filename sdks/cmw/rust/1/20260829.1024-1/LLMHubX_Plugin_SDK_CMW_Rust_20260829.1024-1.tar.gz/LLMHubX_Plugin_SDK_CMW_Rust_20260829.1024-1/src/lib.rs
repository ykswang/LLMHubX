#![no_std]

extern crate alloc;

use alloc::vec::Vec;

pub const SDK_VERSION: &str = "20260826.0322-1";
pub const TARGET_ABI_LEVEL: u32 = 1;

pub mod bindings {
    wit_bindgen::generate!({
        path: "wit",
        world: "plugin",
        pub_export_macro: true,
    });
}

pub use bindings::exports::llmhubx::plugin_level_1::{guest, resource_provider};
pub use bindings::llmhubx::plugin_level_1::{
    host, resource_common, resource_consumer, resource_kv, resource_relational_query,
    resource_relational_schema, types,
};

pub trait ResourceDispatch {
    fn declarations() -> resource_common::CapabilityDeclarations {
        resource_common::CapabilityDeclarations {
            provides: Vec::new(),
            requires: Vec::new(),
        }
    }

    fn call_kv(
        _call: resource_provider::ProviderKvCall,
    ) -> Result<resource_kv::KvResponse, resource_common::ResourceError> {
        Err(provider_unavailable())
    }

    fn call_relational(
        _call: resource_provider::ProviderRelationalCall,
    ) -> Result<
        resource_relational_query::RelationalResponse,
        resource_common::ResourceError,
    > {
        Err(provider_unavailable())
    }
}

pub mod resource {
    use super::{resource_common, resource_relational_query as query};
    use alloc::{string::String, vec::Vec};

    pub struct QueryBuilder {
        value: query::Query,
    }

    impl QueryBuilder {
        pub fn new(table: impl Into<String>, limit: u32) -> Self {
            Self {
                value: query::Query {
                    table: table.into(),
                    projection: Vec::new(),
                    filter: None,
                    order_by: Vec::new(),
                    limit,
                    offset: 0,
                },
            }
        }

        pub fn projection(mut self, columns: Vec<String>) -> Self {
            self.value.projection = columns;
            self
        }

        pub fn filter(mut self, filter: query::Filter) -> Self {
            self.value.filter = Some(filter);
            self
        }

        pub fn order_by(mut self, items: Vec<query::OrderItem>) -> Self {
            self.value.order_by = items;
            self
        }

        pub fn offset(mut self, offset: u64) -> Self {
            self.value.offset = offset;
            self
        }

        pub fn build(self) -> query::Query {
            self.value
        }
    }

    #[derive(Default)]
    pub struct FilterBuilder {
        nodes: Vec<query::FilterNode>,
    }

    impl FilterBuilder {
        pub fn push(&mut self, node: query::FilterNode) -> u32 {
            let index = self.nodes.len() as u32;
            self.nodes.push(node);
            index
        }

        pub fn finish(self, root: u32) -> query::Filter {
            query::Filter {
                nodes: self.nodes,
                root,
            }
        }
    }

    pub fn error(code: resource_common::ResourceErrorCode) -> resource_common::ResourceError {
        resource_common::ResourceError {
            code,
            message: None,
        }
    }
}

pub mod testing {
    use super::resource_common::{ResourceError, ResourceErrorCode};

    pub fn assert_error_code<T>(result: Result<T, ResourceError>, expected: ResourceErrorCode) {
        match result {
            Err(error) => assert!(error.code == expected),
            Ok(_) => panic!("expected Resource error"),
        }
    }
}

impl<T: ResourceDispatch> resource_provider::Guest for T {
    fn declarations() -> resource_common::CapabilityDeclarations {
        T::declarations()
    }

    fn call_kv(
        call: resource_provider::ProviderKvCall,
    ) -> Result<resource_kv::KvResponse, resource_common::ResourceError> {
        T::call_kv(call)
    }

    fn call_relational(
        call: resource_provider::ProviderRelationalCall,
    ) -> Result<
        resource_relational_query::RelationalResponse,
        resource_common::ResourceError,
    > {
        T::call_relational(call)
    }
}

fn provider_unavailable() -> resource_common::ResourceError {
    resource_common::ResourceError {
        code: resource_common::ResourceErrorCode::ProviderUnavailable,
        message: None,
    }
}

#[cfg(test)]
mod tests {
    use super::{resource::*, resource_relational_query as query};
    use alloc::vec;

    #[test]
    fn canonical_encoder_matches_every_frozen_level_one_fixture() {
        let document: serde_json::Value =
            serde_json::from_str(include_str!("../conformance/canonical-fixtures.json")).unwrap();
        let fixtures = document["fixtures"].as_array().unwrap();
        assert!(fixtures.len() > 100);
        for fixture in fixtures {
            let value: serde_json::Value =
                serde_json::from_str(fixture["input_json"].as_str().unwrap()).unwrap();
            let actual = serde_json_canonicalizer::to_string(&value).unwrap();
            assert_eq!(actual, fixture["canonical_json"], "{}", fixture["id"]);
        }
    }

    #[test]
    fn relational_builders_keep_the_typed_wit_shape() {
        let mut filter = FilterBuilder::default();
        let root = filter.push(query::FilterNode::NullTest(query::NullTest {
            column: "deleted_at".into(),
            is_null: true,
        }));
        let query = QueryBuilder::new("items", 100)
            .projection(vec!["id".into(), "name".into()])
            .filter(filter.finish(root))
            .offset(5)
            .build();
        assert_eq!(query.table, "items");
        assert_eq!(query.limit, 100);
        assert_eq!(query.offset, 5);
        assert!(query.filter.is_some());
    }
}
