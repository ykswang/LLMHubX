#![no_std]

extern crate alloc;

pub const SDK_VERSION: &str = "20260910.1739-3";
pub const TARGET_ABI_LEVEL: u32 = 3;

pub use llmhubx_cmw_rust_sdk as level_one;

pub mod bindings {
    wit_bindgen::generate!({
        path: "wit",
        world: "business-observation",
        pub_export_macro: true,
    });
}

pub use bindings::exports::llmhubx::plugin_level_3::observation_declarations;
pub use bindings::llmhubx::plugin_level_3::{business_types, observation_host};

pub trait BusinessObservationDispatch {
    fn observation_declarations() -> business_types::DeclarationSet;
}

impl<T: BusinessObservationDispatch> observation_declarations::Guest for T {
    fn declarations() -> business_types::DeclarationSet {
        T::observation_declarations()
    }
}
