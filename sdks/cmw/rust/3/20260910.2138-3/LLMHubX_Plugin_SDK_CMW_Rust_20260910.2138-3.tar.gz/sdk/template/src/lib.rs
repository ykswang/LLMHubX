use llmhubx_cmw_rust_sdk_v3::{
    BusinessObservationDispatch,
    business_types::*,
    level_one::{self, ResourceDispatch, guest::Guest, types},
    observation_host,
};

struct Plugin;
impl ResourceDispatch for Plugin {}

impl BusinessObservationDispatch for Plugin {
    fn observation_declarations() -> DeclarationSet {
        DeclarationSet {
            operations: vec![OperationDeclaration {
                id: "request.inspect".into(),
                label: "请求结构检查".into(),
                contribution_id: "request-inspector".into(),
                core_order: Some(1),
                settlement: Settlement::CallResult,
            }],
            metrics: vec![MetricDeclaration {
                id: "request.message_count".into(),
                label: "模型收到的消息条目".into(),
                description: "本次最终请求中的消息条目数量，不是聊天轮数".into(),
                kind: MetricKind::Gauge,
                unit: MetricUnit::Count,
                aggregation: Aggregation::Latest,
                core_order: Some(1),
                display_role: DisplayRole::Value,
                contribution_id: "request-inspector".into(),
                operation_id: "request.inspect".into(),
                states: None,
            }],
        }
    }
}

impl Guest for Plugin {
    fn implemented_hooks() -> Vec<types::HookId> {
        vec![types::HookId::RequestObserve]
    }

    fn invoke(input: types::HookInput) -> types::HookOutput {
        if let types::HookInput::RequestObserve(call) = input {
            if let BeginResult::Accepted(handle) =
                observation_host::begin_operation("request-inspector", "request.inspect", None)
            {
                // 观测关闭或配额拒绝不改变请求处理结果。
                let _ = observation_host::report(
                    handle,
                    &BusinessReport {
                        sequence: 1,
                        stage: ReportStage::Started,
                        values: vec![],
                        reason_code: None,
                        message: None,
                        context_evidence: None,
                    },
                );
                let _ = observation_host::finish_operation(
                    handle,
                    PluginOutcome::Completed,
                    &BusinessReport {
                        sequence: 2,
                        stage: ReportStage::Result,
                        values: vec![MetricSample {
                            id: "request.message_count".into(),
                            value: MetricValue::Number(
                                call.final_member_request.prompts.len() as f64
                            ),
                        }],
                        reason_code: None,
                        message: None,
                        context_evidence: None,
                    },
                );
            }
        }
        types::HookOutput {
            result: types::HookResult::Observed,
            opaque_state: None,
            observations: vec![],
        }
    }
}

level_one::bindings::export!(Plugin with_types_in level_one::bindings);
llmhubx_cmw_rust_sdk_v3::bindings::export!(Plugin with_types_in llmhubx_cmw_rust_sdk_v3::bindings);
