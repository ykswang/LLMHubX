#![no_std]

extern crate alloc;

use alloc::vec::Vec;

pub const SDK_VERSION: &str = "20260830.0138-2";
pub const TARGET_ABI_LEVEL: u32 = 2;

pub use llmhubx_cmw_rust_sdk as level_one;

pub mod bindings {
    wit_bindgen::generate!({
        path: "wit",
        world: "workflow-contributions",
        pub_export_macro: true,
    });
}

pub mod tool_bindings {
    wit_bindgen::generate!({
        path: "wit",
        world: "tool-component",
        pub_export_macro: true,
    });
}

pub use bindings::exports::llmhubx::plugin_level_1::agent_workflow_contributions;
pub use bindings::llmhubx::plugin_level_1::agent_workflow_common;

pub trait WorkflowContributionDispatch {
    fn workflow_declarations() -> agent_workflow_common::WorkflowContributionDeclarations {
        agent_workflow_common::WorkflowContributionDeclarations {
            workflows: Vec::new(),
            experts: Vec::new(),
        }
    }
}

impl<T: WorkflowContributionDispatch> agent_workflow_contributions::Guest for T {
    fn declarations() -> agent_workflow_common::WorkflowContributionDeclarations {
        T::workflow_declarations()
    }
}

pub trait ToolDispatch {
    fn invoke(export_name: alloc::string::String, input_json: alloc::string::String)
        -> Result<alloc::string::String, alloc::string::String>;
}

impl<T: ToolDispatch>
    tool_bindings::exports::llmhubx::plugin_level_1::tool_runtime::Guest for T
{
    fn invoke(
        export_name: alloc::string::String,
        input_json: alloc::string::String,
    ) -> Result<alloc::string::String, alloc::string::String> {
        T::invoke(export_name, input_json)
    }
}
