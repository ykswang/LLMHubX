#!/bin/sh
set -eu

if [ "$#" -ne 3 ]; then
  echo "用法：package-plugin.sh <plugin.toml> <component.wasm> <output.lhxp>" >&2
  exit 2
fi

manifest=$1
component=$2
output=$3

if [ ! -f "$manifest" ]; then
  echo "找不到 plugin.toml：$manifest" >&2
  exit 1
fi
if [ ! -f "$component" ]; then
  echo "找不到 component.wasm：$component" >&2
  exit 1
fi
case "$output" in
  *.lhxp) ;;
  *) echo "输出文件扩展名必须是 .lhxp：$output" >&2; exit 1 ;;
esac
if [ -e "$output" ]; then
  echo "输出文件已经存在，拒绝覆盖：$output" >&2
  exit 1
fi

staging=$(mktemp -d "${TMPDIR:-/tmp}/llmhubx-cmw-package.XXXXXX")
trap 'rm -rf "$staging"' EXIT INT TERM
cp "$manifest" "$staging/plugin.toml"
cp "$component" "$staging/component.wasm"
manifest_dir=$(CDPATH= cd -- "$(dirname -- "$manifest")" && pwd)
if [ -d "$manifest_dir/assets" ]; then
  cp -R "$manifest_dir/assets" "$staging/assets"
fi
mkdir -p "$(dirname "$output")"
output=$(cd "$(dirname "$output")" && pwd)/$(basename "$output")
(
  cd "$staging"
  if [ -d assets ]; then
    zip -X -9 -q -r "$output" plugin.toml component.wasm assets
  else
    zip -X -9 -q "$output" plugin.toml component.wasm
  fi
)
