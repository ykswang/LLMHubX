use llmhubx_cmw_rust_sdk::{ResourceDispatch, guest::Guest, types::*};

struct Plugin;
impl ResourceDispatch for Plugin {}

impl Guest for Plugin {
    fn implemented_hooks() -> Vec<HookId> {
        vec![HookId::RequestTransform]
    }

    fn invoke(_input: HookInput) -> HookOutput {
        HookOutput {
            result: HookResult::Unchanged,
            opaque_state: None,
            observations: Vec::new(),
        }
    }
}

llmhubx_cmw_rust_sdk::bindings::export!(Plugin with_types_in llmhubx_cmw_rust_sdk::bindings);
