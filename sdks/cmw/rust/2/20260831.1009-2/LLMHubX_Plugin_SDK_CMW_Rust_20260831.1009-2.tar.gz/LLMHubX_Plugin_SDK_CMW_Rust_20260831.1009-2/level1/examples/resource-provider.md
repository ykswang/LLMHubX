# Resource Provider 最小示例

纯 Provider 的 Manifest 可以没有 Hook，但必须声明能力和 scoped Workspace 权限：

```toml
hooks = []
permissions = ["resource.provider.workspace"]

[capabilities]
provides = ["resource.kv"]
```

实现 `ResourceDispatch` 后通过 SDK 的标准 world 导出：

```rust
use llmhubx_cmw_rust_sdk::{
    ResourceDispatch, resource_common, resource_kv, resource_provider,
};

struct Provider;

impl ResourceDispatch for Provider {
    fn declarations() -> resource_common::CapabilityDeclarations {
        resource_common::CapabilityDeclarations {
            provides: vec![resource_common::CapabilityId::ResourceKv],
            requires: vec![],
        }
    }

    fn call_kv(
        call: resource_provider::ProviderKvCall,
    ) -> Result<resource_kv::KvResponse, resource_common::ResourceError> {
        // 使用 call.namespace_token 作为不透明物理分区键；不要解析或记录它。
        dispatch_to_backend(call)
    }
}
```

Provider 只能通过 `host::acquire_workspace()` 获得自己的 scoped Workspace。不得把物理路径、
SQL、绑定值或业务数据写入错误消息和日志。
