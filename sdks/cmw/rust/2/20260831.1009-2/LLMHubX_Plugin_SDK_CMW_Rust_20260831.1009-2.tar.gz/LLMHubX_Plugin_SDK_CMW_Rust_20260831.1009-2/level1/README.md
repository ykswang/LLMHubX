# LLMHubX CMW Rust SDK

该 SDK 绑定 LLMHubX Plugin ABI Level 1 的 `llmhubx:plugin-level-1/plugin` world。

插件实现 `guest::Guest`，再调用生成的 `export!` 宏导出 Component。构建目标固定为：

```sh
cargo build --release --target wasm32-wasip2
```

`wit/` 是 SDK 发布时冻结的 ABI Level 1 快照。运行 `cargo test` 检查绑定，运行
`cargo build --manifest-path template/Cargo.toml --release --target wasm32-wasip2`
验证随包模板可以独立构建。

构建完成后使用随包工具生成固定结构的 `.lhxp`：

```sh
tools/package-plugin.sh plugin.toml \
  target/wasm32-wasip2/release/my_plugin.wasm \
  my-plugin_20260828.1200-1.lhxp
```

工具只写入根目录 `plugin.toml` 和 `component.wasm`，并拒绝覆盖已有产物。

## Resource Capability

SDK 导出强类型 `resource_*` WIT 绑定，并提供 `resource::QueryBuilder`、
`resource::FilterBuilder` 和 `testing::assert_error_code`。最小示例见：

- `examples/resource-consumer.md`
- `examples/resource-provider.md`

Resource Consumer 不传 Provider ID、Namespace、Workspace 或数据库路径。Host 根据调用
Component 的插件 ID 注入 Namespace，并在每次调用检查权限。

Host 不会自动重试已经派发给 Provider 的调用。读失败是否重试由 Consumer 决定；写调用
返回 `provider-unavailable` 时，后端提交结果仍可能未知。Consumer 必须使用业务幂等 Key、
稳定主键或等价机制处理重试，不能假设失败响应代表写入一定没有发生。
