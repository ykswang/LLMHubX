# Resource Consumer 最小示例

Manifest 同时声明依赖与最小权限：

```toml
[capabilities]
requires = ["resource.kv"]

permissions = ["resource.kv.read", "resource.kv.write"]
```

Component 直接调用强类型 import；请求中没有 Provider、Namespace 或路径：

```rust
use llmhubx_cmw_rust_sdk::{resource_consumer, resource_kv};

let result = resource_consumer::call_kv(&resource_kv::KvRequest::Put(
    resource_kv::KvPut {
        key: "migration:3".into(),
        value: b"complete".to_vec(),
        expiry: resource_kv::KvExpiry::Persistent,
    },
));
```

写调用失败后的提交状态可能未知。示例使用稳定 Key，使相同业务写入可以安全覆盖，而不是
依赖 Host 自动重试。
