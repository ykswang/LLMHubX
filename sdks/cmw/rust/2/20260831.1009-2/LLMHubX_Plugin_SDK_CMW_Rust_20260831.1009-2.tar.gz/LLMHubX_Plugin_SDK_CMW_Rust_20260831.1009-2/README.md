# LLMHubX CMW Rust SDK — ABI Level 2

该增量 SDK 依赖 Level 1 Rust SDK，并生成 `workflow-contributions` world 的强类型绑定。

Level 2 插件同时实现：

```rust
llmhubx_cmw_rust_sdk::ResourceDispatch
llmhubx_cmw_rust_sdk_v2::WorkflowContributionDispatch
```

并分别调用两个 SDK 的 `bindings::export!`。Workflow 与 Expert 的详细定义、角色 protocol 和 AGENT.md 放在 `plugin.toml` 与 Bundle assets 中；运行时 declaration 只重复身份和 contract revision，供 Host 做一致性校验。

`plugins/official/basic-workflow`、`plugins/official/general-expert` 和 `plugins/official/basic-steward` 是可构建参考实现。
