#![no_std]

pub const SDK_VERSION: &str = "20260826.0322-1";
pub const TARGET_ABI_LEVEL: u32 = 1;

pub mod bindings {
    wit_bindgen::generate!({
        path: "wit",
        world: "plugin",
        pub_export_macro: true,
    });
}

pub use bindings::exports::llmhubx::plugin_level_1::guest;
pub use bindings::llmhubx::plugin_level_1::{host, types};

#[cfg(test)]
mod tests {
    #[test]
    fn canonical_encoder_matches_every_frozen_level_one_fixture() {
        let document: serde_json::Value =
            serde_json::from_str(include_str!("../conformance/canonical-fixtures.json")).unwrap();
        let fixtures = document["fixtures"].as_array().unwrap();
        assert!(fixtures.len() > 100);
        for fixture in fixtures {
            let value: serde_json::Value =
                serde_json::from_str(fixture["input_json"].as_str().unwrap()).unwrap();
            let actual = serde_json_canonicalizer::to_string(&value).unwrap();
            assert_eq!(actual, fixture["canonical_json"], "{}", fixture["id"]);
        }
    }
}
