# LLMHubX CMW Rust SDK

该 SDK 绑定 LLMHubX Plugin ABI Level 1 的 `llmhubx:plugin-level-1/plugin` world。

插件实现 `guest::Guest`，再调用生成的 `export!` 宏导出 Component。构建目标固定为：

```sh
cargo build --release --target wasm32-wasip2
```

`wit/` 是 SDK 发布时冻结的 ABI Level 1 快照。运行 `cargo test` 检查绑定，运行
`cargo build --manifest-path template/Cargo.toml --release --target wasm32-wasip2`
验证随包模板可以独立构建。
