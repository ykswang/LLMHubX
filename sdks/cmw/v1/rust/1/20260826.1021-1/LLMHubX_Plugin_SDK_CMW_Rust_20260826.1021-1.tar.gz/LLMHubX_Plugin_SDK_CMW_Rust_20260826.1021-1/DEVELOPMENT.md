# 开发与调试

`wit/` 由 ABI Level 1 冻结快照生成。插件实现 `guest::Guest::implemented_hooks` 与 `guest::Guest::invoke`，再通过 SDK 的 `bindings::export!` 导出 Component。

`implemented_hooks` 必须非空、无重复并与 `plugin.toml` 完全一致。`invoke` 的输出 variant 必须与输入 Hook 对应；Observe Hook 不得返回 opaque state。

运行 `cargo test` 检查绑定可编译；使用 `wasm32-wasip2` Release 构建 CMW Component。
