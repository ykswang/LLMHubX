use base64::{Engine, engine::general_purpose::URL_SAFE_NO_PAD};
use extism_pdk::{FnResult, host_fn};
use serde::{Deserialize, Deserializer, Serialize, Serializer, de::Error as _};

mod generated;
pub use generated::*;

pub const SDK_VERSION: &str = "20260826.0346-1";
pub const TARGET_ABI_LEVEL: u32 = 1;

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct HookEnvelope<T> {
    abi_level: u32,
    hook: HookId,
    invocation_id: String,
    config: Vec<ConfigEntry>,
    #[serde(with = "optional_bytes")]
    opaque_state: Option<Vec<u8>>,
    media_export_destinations: Vec<MediaExportDestination>,
    input: T,
}

#[derive(Clone, Debug)]
pub enum ExtismResult<C> {
    Unchanged,
    Changes(Vec<C>),
    ForwardTo(String),
    Observed,
}

#[derive(Clone, Debug)]
pub struct ExtismOutput<C> {
    result: ExtismResult<C>,
    opaque_state: Option<Vec<u8>>,
    observations: Vec<ObservationEntry>,
}

impl<C> ExtismOutput<C> {
    pub fn with_opaque_state(mut self, state: Option<Vec<u8>>) -> Self {
        self.opaque_state = state;
        self
    }
}

pub fn unchanged<C>() -> ExtismOutput<C> {
    unchanged_with_observations(Vec::new())
}

pub fn unchanged_with_observations<C>(observations: Vec<ObservationEntry>) -> ExtismOutput<C> {
    ExtismOutput {
        result: ExtismResult::Unchanged,
        opaque_state: None,
        observations,
    }
}

pub fn changes<C>(changes: Vec<C>) -> ExtismOutput<C> {
    changes_with_observations(changes, Vec::new())
}

pub fn changes_with_observations<C>(
    changes: Vec<C>,
    observations: Vec<ObservationEntry>,
) -> ExtismOutput<C> {
    ExtismOutput {
        result: ExtismResult::Changes(changes),
        opaque_state: None,
        observations,
    }
}

pub fn request_changes(changes: Vec<RequestChange>) -> ExtismOutput<RequestChange> {
    self::changes(changes)
}

pub fn member_changes(changes: Vec<MemberChange>) -> ExtismOutput<MemberChange> {
    self::changes(changes)
}

pub fn member_changes_with_observations(
    changes: Vec<MemberChange>,
    observations: Vec<ObservationEntry>,
) -> ExtismOutput<MemberChange> {
    self::changes_with_observations(changes, observations)
}

pub fn response_changes(changes: Vec<ResponseChange>) -> ExtismOutput<ResponseChange> {
    self::changes(changes)
}

pub fn forward_to(model_id: impl Into<String>) -> ExtismOutput<()> {
    ExtismOutput {
        result: ExtismResult::ForwardTo(model_id.into()),
        opaque_state: None,
        observations: Vec::new(),
    }
}

pub fn observed(observations: Vec<ObservationEntry>) -> ExtismOutput<()> {
    ExtismOutput {
        result: ExtismResult::Observed,
        opaque_state: None,
        observations,
    }
}

pub fn request_transform(
    input: String,
    transform: impl FnOnce(HookContext, ExtismRequestTransformInput) -> ExtismOutput<RequestChange>,
) -> FnResult<String> {
    run_transform(input, HookId::RequestTransform, transform)
}

pub fn logical_model_forward(
    input: String,
    transform: impl FnOnce(HookContext, ExtismLogicalModelForwardInput) -> ExtismOutput<()>,
) -> FnResult<String> {
    run_unit(
        input,
        HookId::LogicalModelForward,
        UnitResultKind::Forward,
        transform,
    )
}

pub fn member_request_transform(
    input: String,
    transform: impl FnOnce(HookContext, MemberRequestView) -> ExtismOutput<MemberChange>,
) -> FnResult<String> {
    run_transform(
        input,
        HookId::MemberRequestTransform,
        move |context, input: ExtismMemberRequestTransformInput| transform(context, input.request),
    )
}

pub fn request_observe(
    input: String,
    observe: impl FnOnce(HookContext, ExtismRequestObserveInput) -> ExtismOutput<()>,
) -> FnResult<String> {
    run_unit(
        input,
        HookId::RequestObserve,
        UnitResultKind::Observed,
        observe,
    )
}

pub fn response_transform(
    input: String,
    transform: impl FnOnce(HookContext, ExtismResponseTransformInput) -> ExtismOutput<ResponseChange>,
) -> FnResult<String> {
    run_transform(input, HookId::ResponseTransform, transform)
}

pub fn response_observe(
    input: String,
    observe: impl FnOnce(HookContext, ExtismResponseObserveInput) -> ExtismOutput<()>,
) -> FnResult<String> {
    run_unit(
        input,
        HookId::ResponseObserve,
        UnitResultKind::Observed,
        observe,
    )
}

fn run_transform<I, C>(
    input: String,
    expected_hook: HookId,
    transform: impl FnOnce(HookContext, I) -> ExtismOutput<C>,
) -> FnResult<String>
where
    I: for<'de> Deserialize<'de>,
    C: Serialize,
{
    let (context, input) = decode_envelope(input, expected_hook)?;
    let output = transform(context, input);
    match &output.result {
        ExtismResult::Unchanged => {}
        ExtismResult::Changes(changes) if !changes.is_empty() => {}
        ExtismResult::Changes(_) => return Err(extism_pdk::Error::msg("changes 必须非空").into()),
        _ => return Err(extism_pdk::Error::msg("Hook result 与 Transform Hook 不匹配").into()),
    }
    encode_output(expected_hook, output)
}

#[derive(Clone, Copy)]
enum UnitResultKind {
    Forward,
    Observed,
}

fn run_unit<I>(
    input: String,
    expected_hook: HookId,
    expected_result: UnitResultKind,
    transform: impl FnOnce(HookContext, I) -> ExtismOutput<()>,
) -> FnResult<String>
where
    I: for<'de> Deserialize<'de>,
{
    let (context, input) = decode_envelope(input, expected_hook)?;
    let output = transform(context, input);
    let valid = matches!(
        (&output.result, expected_result),
        (
            ExtismResult::Unchanged | ExtismResult::ForwardTo(_),
            UnitResultKind::Forward
        ) | (ExtismResult::Observed, UnitResultKind::Observed)
    );
    if !valid
        || matches!(expected_result, UnitResultKind::Observed) && output.opaque_state.is_some()
    {
        return Err(extism_pdk::Error::msg("Hook result 或 opaque state 与 Hook 不匹配").into());
    }
    encode_output(expected_hook, output)
}

fn decode_envelope<I>(input: String, expected_hook: HookId) -> FnResult<(HookContext, I)>
where
    I: for<'de> Deserialize<'de>,
{
    let envelope: HookEnvelope<I> = serde_json::from_str(&input)?;
    if envelope.abi_level != TARGET_ABI_LEVEL || envelope.hook != expected_hook {
        return Err(extism_pdk::Error::msg("ABI Level 或 Hook 不匹配").into());
    }
    ensure_unique_entries(&envelope.config, |entry| &entry.key, "config")?;
    Ok((
        HookContext {
            abi_level: envelope.abi_level,
            invocation_id: envelope.invocation_id,
            config: envelope.config,
            opaque_state: envelope.opaque_state,
            media_export_destinations: envelope.media_export_destinations,
        },
        envelope.input,
    ))
}

#[derive(Serialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
enum WireResult<C> {
    Unchanged,
    Changes { changes: Vec<C> },
    ForwardTo { model_id: String },
    Observed,
}

#[derive(Serialize)]
struct WireOutput<C> {
    abi_level: u32,
    hook: HookId,
    result: WireResult<C>,
    #[serde(with = "optional_bytes")]
    opaque_state: Option<Vec<u8>>,
    observations: Vec<ObservationEntry>,
}

fn encode_output<C: Serialize>(hook: HookId, output: ExtismOutput<C>) -> FnResult<String> {
    ensure_unique_entries(&output.observations, |entry| &entry.key, "observations")?;
    let result = match output.result {
        ExtismResult::Unchanged => WireResult::Unchanged,
        ExtismResult::Changes(changes) => WireResult::Changes { changes },
        ExtismResult::ForwardTo(model_id) => WireResult::ForwardTo { model_id },
        ExtismResult::Observed => WireResult::Observed,
    };
    Ok(serde_json_canonicalizer::to_string(&WireOutput {
        abi_level: TARGET_ABI_LEVEL,
        hook,
        result,
        opaque_state: output.opaque_state,
        observations: output.observations,
    })?)
}

fn ensure_unique_entries<T>(
    entries: &[T],
    key: impl Fn(&T) -> &String,
    name: &str,
) -> Result<(), extism_pdk::Error> {
    for (index, entry) in entries.iter().enumerate() {
        if entries[..index]
            .iter()
            .any(|previous| key(previous) == key(entry))
        {
            return Err(extism_pdk::Error::msg(format!("{name} 包含重复 key")));
        }
    }
    Ok(())
}

#[derive(Deserialize)]
#[serde(untagged)]
enum MediaExportWireResult {
    Ok { ok: MediaExportAccepted },
    Error { error: HostError },
}

#[host_fn("llmhubx")]
extern "ExtismHost" {
    fn submit_media_export(input: String) -> String;
}

pub fn submit_media_export_request(
    request: &MediaExportRequest,
) -> Result<MediaExportAccepted, HostError> {
    let input = serde_json_canonicalizer::to_string(request).map_err(|_| internal_error())?;
    // SAFETY: Extism PDK copies the UTF-8 input/output through the declared PTR ABI.
    let response = unsafe { submit_media_export(input) }.map_err(|_| internal_error())?;
    match serde_json::from_str(&response).map_err(|_| internal_error())? {
        MediaExportWireResult::Ok { ok } => Ok(ok),
        MediaExportWireResult::Error { error } => Err(error),
    }
}

pub fn request_media_export(
    request: &MediaExportRequest,
) -> Result<MediaExportAccepted, HostError> {
    submit_media_export_request(request)
}

fn internal_error() -> HostError {
    HostError {
        code: error_code::INTERNAL_ERROR.into(),
        message: None,
    }
}

pub mod error_code {
    pub const INVALID_ARGUMENT: &str = "invalid_argument";
    pub const PERMISSION_DENIED: &str = "permission_denied";
    pub const INVALID_HANDLE: &str = "invalid_handle";
    pub const INVALID_DESTINATION: &str = "invalid_destination";
    pub const OUT_OF_SCOPE: &str = "out_of_scope";
    pub const RESOURCE_LIMIT_EXCEEDED: &str = "resource_limit_exceeded";
    pub const IO_FAILED: &str = "io_failed";
    pub const INTERNAL_ERROR: &str = "internal_error";
}

mod u64_string {
    use super::*;

    pub fn serialize<S>(value: &u64, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        serializer.collect_str(value)
    }

    pub fn deserialize<'de, D>(deserializer: D) -> Result<u64, D::Error>
    where
        D: Deserializer<'de>,
    {
        parse_u64(String::deserialize(deserializer)?).map_err(D::Error::custom)
    }
}

mod optional_u64_string {
    use super::*;

    pub fn serialize<S>(value: &Option<u64>, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        match value {
            Some(value) => serializer.serialize_some(&value.to_string()),
            None => serializer.serialize_none(),
        }
    }

    pub fn deserialize<'de, D>(deserializer: D) -> Result<Option<u64>, D::Error>
    where
        D: Deserializer<'de>,
    {
        Option::<String>::deserialize(deserializer)?
            .map(parse_u64)
            .transpose()
            .map_err(D::Error::custom)
    }
}

fn parse_u64(value: String) -> Result<u64, &'static str> {
    if value.is_empty()
        || !value.bytes().all(|byte| byte.is_ascii_digit())
        || value.len() > 1 && value.starts_with('0')
    {
        return Err("u64 必须是规范十进制 string");
    }
    value.parse().map_err(|_| "u64 超出范围")
}

mod optional_bytes {
    use super::*;

    pub fn serialize<S>(value: &Option<Vec<u8>>, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        match value {
            Some(value) => serializer.serialize_some(&URL_SAFE_NO_PAD.encode(value)),
            None => serializer.serialize_none(),
        }
    }

    pub fn deserialize<'de, D>(deserializer: D) -> Result<Option<Vec<u8>>, D::Error>
    where
        D: Deserializer<'de>,
    {
        Option::<String>::deserialize(deserializer)?
            .map(|value| {
                let bytes = URL_SAFE_NO_PAD.decode(&value).map_err(D::Error::custom)?;
                if URL_SAFE_NO_PAD.encode(&bytes) != value {
                    return Err(D::Error::custom("bytes 必须是无 padding base64url"));
                }
                Ok(bytes)
            })
            .transpose()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::{Value, json};

    fn envelope(hook: &str, input: Value) -> String {
        json!({
            "abi_level": 1,
            "hook": hook,
            "invocation_id": "inv",
            "config": [],
            "opaque_state": null,
            "media_export_destinations": [],
            "input": input,
        })
        .to_string()
    }

    fn neutral_request() -> Value {
        json!({
            "parameters": {
                "temperature": null,
                "top_p": null,
                "max_output_tokens": null,
                "stop_sequences": null,
                "seed": null,
                "candidate_count": null,
                "output": null,
                "search": null,
                "store_response": null,
            },
            "prompts": [],
            "headers": [],
            "media": [],
        })
    }

    fn neutral_response(streaming: bool) -> Value {
        json!({"streaming": streaming, "text_parts": [], "media": []})
    }

    #[test]
    fn all_six_hooks_use_generated_level_one_types_and_canonical_wire() {
        request_transform(
            envelope("request-transform", json!({"request": neutral_request()})),
            |_context, _input| unchanged(),
        )
        .unwrap();
        logical_model_forward(
            envelope(
                "logical-model-forward",
                json!({"input": {
                    "current_model_id": "model-a",
                    "models": [],
                    "request": neutral_request(),
                }}),
            ),
            |_context, _input| forward_to("model-b"),
        )
        .unwrap();
        let member = envelope(
            "member-request-transform",
            json!({"request": {
                "reasoning": {"enabled": true, "effort": "high", "budget_tokens": null},
                "capabilities": {"toggle": true, "efforts": [], "budget_tokens": null},
            }}),
        );
        let output = member_request_transform(member.into(), |_context, _request| {
            member_changes(vec![MemberChange::SetReasoningEffort("none".into())])
        })
        .unwrap();
        assert_eq!(
            output,
            r#"{"abi_level":1,"hook":"member-request-transform","observations":[],"opaque_state":null,"result":{"changes":[{"kind":"set_reasoning_effort","value":"none"}],"kind":"changes"}}"#
        );
        request_observe(
            envelope(
                "request-observe",
                json!({
                    "original_request": neutral_request(),
                    "final_member_request": neutral_request(),
                }),
            ),
            |_context, _input| observed(Vec::new()),
        )
        .unwrap();
        response_transform(
            envelope(
                "response-transform",
                json!({"response": neutral_response(false)}),
            ),
            |_context, _input| unchanged(),
        )
        .unwrap();
        response_observe(
            envelope(
                "response-observe",
                json!({
                    "upstream_response": neutral_response(true),
                    "client_response": neutral_response(true),
                    "stream_ended": false,
                    "stream_interrupted": false,
                }),
            ),
            |_context, _input| observed(Vec::new()),
        )
        .unwrap();
    }

    #[test]
    fn canonical_encoder_matches_every_frozen_level_one_fixture() {
        let document: Value =
            serde_json::from_str(include_str!("../conformance/canonical-fixtures.json")).unwrap();
        let fixtures = document["fixtures"].as_array().unwrap();
        assert!(fixtures.len() > 100);
        for fixture in fixtures {
            let value: Value =
                serde_json::from_str(fixture["input_json"].as_str().unwrap()).unwrap();
            let actual = serde_json_canonicalizer::to_string(&value).unwrap();
            assert_eq!(actual, fixture["canonical_json"], "{}", fixture["id"]);
        }
    }
}
