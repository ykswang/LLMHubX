# LLMHubX Extism Rust SDK

本 SDK 面向 `extism/v1`，绑定 Plugin ABI Level 1。插件 export 使用 Extism PDK 的字节调用边界，SDK 负责严格 envelope、`u64` 十进制字符串和无 padding base64url 编码。

```rust
use extism_pdk::*;
use llmhubx_extism_rust_sdk::{member_request_transform, MemberRequestView};

#[plugin_fn]
pub fn llmhubx_member_request_transform(input: String) -> FnResult<String> {
    member_request_transform(input, |_context, request: MemberRequestView| {
        // 返回 SDK 提供的类型化 HookOutput。
        llmhubx_extism_rust_sdk::unchanged()
    })
}
```

构建目标为 `wasm32-unknown-unknown`。插件不得启用 WASI、HTTP 或其他 Host import。
运行 `cargo test` 检查 SDK，运行
`cargo build --manifest-path template/Cargo.toml --release --target wasm32-unknown-unknown`
验证随包模板可以独立构建。
