# 开发与调试

`src/generated.rs` 和 `wit/` 均由仓库根目录的 Level 1 WIT 生成，不应手工修改。六个 Hook 分别使用 `request_transform`、`logical_model_forward`、`member_request_transform`、`request_observe`、`response_transform` 和 `response_observe` wrapper。

同步 Hook 可以通过 `with_opaque_state` 返回新快照；Observe Hook 必须使用 `observed`，不能返回 state。媒体导出只在 Observe Hook 中调用 `submit_media_export_request`。

运行 `cargo test` 检查六 Hook wire、JCS canonical JSON、u64 十进制 string 和 bytes base64url 编码。
