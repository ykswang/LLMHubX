use extism_pdk::*;
use llmhubx_extism_rust_sdk::{request_transform, unchanged};

#[plugin_fn]
pub fn llmhubx_request_transform(input: String) -> FnResult<String> {
    request_transform(input, |_context, _input| unchanged())
}
