// 由 scripts/generate-extism-sdk-types.mjs 从 ABI Level 1 WIT 生成，请勿手工编辑。
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum HookId {
    RequestTransform,
    LogicalModelForward,
    MemberRequestTransform,
    RequestObserve,
    ResponseTransform,
    ResponseObserve,
}

pub type ImplementedHookList = Vec<HookId>;

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(tag = "kind", content = "value", rename_all = "snake_case")]
pub enum ConfigValue {
    StringValue(String),
    NumberValue(f64),
    BooleanValue(bool),
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ConfigEntry {
    pub key: String,
    pub value: ConfigValue,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(tag = "kind", content = "value", rename_all = "snake_case")]
pub enum ObservationValue {
    StringValue(String),
    NumberValue(f64),
    BooleanValue(bool),
    StringList(Vec<String>),
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ObservationEntry {
    pub key: String,
    pub value: ObservationValue,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum MessageRole {
    System,
    User,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum MediaOrigin {
    Request,
    Response,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum MediaKind {
    Image,
    Audio,
    Video,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MediaMetadata {
    pub handle: String,
    pub origin: MediaOrigin,
    pub kind: MediaKind,
    pub mime_type: Option<String>,
    #[serde(with = "crate::optional_u64_string")]
    pub byte_length: Option<u64>,
    pub width: Option<u32>,
    pub height: Option<u32>,
    #[serde(with = "crate::optional_u64_string")]
    pub duration_ms: Option<u64>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct PromptTextPart {
    pub part_id: String,
    pub text: String,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct PromptMediaPart {
    pub part_id: String,
    pub media: MediaMetadata,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(tag = "kind", content = "value", rename_all = "snake_case")]
pub enum PromptPart {
    Text(PromptTextPart),
    Media(PromptMediaPart),
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct PromptMessage {
    pub message_id: String,
    pub role: MessageRole,
    pub parts: Vec<PromptPart>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct HeaderEntry {
    pub name: String,
    pub value: String,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(tag = "kind", content = "value", rename_all = "snake_case")]
pub enum InsertionPoint {
    Start,
    End,
    Before(String),
    After(String),
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct HostError {
    pub code: String,
    pub message: Option<String>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MediaExportDestination {
    pub destination_id: String,
    pub label: String,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct HookContext {
    pub abi_level: u32,
    pub invocation_id: String,
    pub config: Vec<ConfigEntry>,
    #[serde(with = "crate::optional_bytes")]
    pub opaque_state: Option<Vec<u8>>,
    pub media_export_destinations: Vec<MediaExportDestination>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(tag = "kind", content = "value", rename_all = "snake_case")]
pub enum OutputKind {
    Text,
    JsonObject,
    JsonSchema(String),
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SearchOptions {
    pub enabled: Option<bool>,
    pub forced: Option<bool>,
    pub return_sources: Option<bool>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct RequestParameters {
    pub temperature: Option<f64>,
    pub top_p: Option<f64>,
    #[serde(with = "crate::optional_u64_string")]
    pub max_output_tokens: Option<u64>,
    pub stop_sequences: Option<Vec<String>>,
    #[serde(with = "crate::optional_u64_string")]
    pub seed: Option<u64>,
    pub candidate_count: Option<u32>,
    pub output: Option<OutputKind>,
    pub search: Option<SearchOptions>,
    pub store_response: Option<bool>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct NeutralRequest {
    pub parameters: RequestParameters,
    pub prompts: Vec<PromptMessage>,
    pub headers: Vec<HeaderEntry>,
    pub media: Vec<MediaMetadata>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ReplacePromptTextChange {
    pub message_id: String,
    pub part_id: String,
    pub text: String,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct InsertPromptMessageChange {
    pub at: InsertionPoint,
    pub role: MessageRole,
    pub text_parts: Vec<String>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct RemovePromptMessageChange {
    pub message_id: String,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SetHeaderChange {
    pub name: String,
    pub value: String,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct RemoveHeaderChange {
    pub name: String,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(tag = "kind", content = "value", rename_all = "snake_case")]
pub enum RequestChange {
    SetTemperature(f64),
    ClearTemperature,
    SetTopP(f64),
    ClearTopP,
    SetMaxOutputTokens(#[serde(with = "crate::u64_string")] u64),
    ClearMaxOutputTokens,
    SetStopSequences(Vec<String>),
    ClearStopSequences,
    SetSeed(#[serde(with = "crate::u64_string")] u64),
    ClearSeed,
    SetCandidateCount(u32),
    ClearCandidateCount,
    SetOutput(OutputKind),
    ClearOutput,
    SetSearch(SearchOptions),
    ClearSearch,
    SetStoreResponse(bool),
    ClearStoreResponse,
    ReplacePromptText(ReplacePromptTextChange),
    InsertPromptMessage(InsertPromptMessageChange),
    RemovePromptMessage(RemovePromptMessageChange),
    SetHeader(SetHeaderChange),
    RemoveHeader(RemoveHeaderChange),
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ReasoningOptions {
    pub enabled: Option<bool>,
    pub effort: Option<String>,
    #[serde(with = "crate::optional_u64_string")]
    pub budget_tokens: Option<u64>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct TokenRange {
    #[serde(with = "crate::u64_string")]
    pub minimum: u64,
    #[serde(with = "crate::optional_u64_string")]
    pub maximum: Option<u64>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ReasoningCapabilities {
    pub toggle: bool,
    pub efforts: Vec<String>,
    pub budget_tokens: Option<TokenRange>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MemberRequestView {
    pub reasoning: ReasoningOptions,
    pub capabilities: ReasoningCapabilities,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(tag = "kind", content = "value", rename_all = "snake_case")]
pub enum MemberChange {
    SetReasoningEnabled(bool),
    ClearReasoningEnabled,
    SetReasoningEffort(String),
    ClearReasoningEffort,
    SetReasoningBudgetTokens(#[serde(with = "crate::u64_string")] u64),
    ClearReasoningBudgetTokens,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct LogicalModelView {
    pub model_id: String,
    pub enabled: bool,
    pub protocols: Vec<String>,
    pub capability_ids: Vec<String>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct LogicalModelInput {
    pub current_model_id: String,
    pub models: Vec<LogicalModelView>,
    pub request: NeutralRequest,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(tag = "kind", content = "value", rename_all = "snake_case")]
pub enum ForwardDecision {
    Unchanged,
    ForwardTo(String),
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum ResponseChannel {
    Thinking,
    Content,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ResponseTextPart {
    pub part_id: String,
    pub channel: ResponseChannel,
    pub text: String,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct NeutralResponse {
    pub streaming: bool,
    pub text_parts: Vec<ResponseTextPart>,
    pub media: Vec<MediaMetadata>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ReplaceResponseTextChange {
    pub part_id: String,
    pub text: String,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct InsertResponseTextChange {
    pub channel: ResponseChannel,
    pub at: InsertionPoint,
    pub text: String,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct RemoveResponseTextChange {
    pub part_id: String,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(tag = "kind", content = "value", rename_all = "snake_case")]
pub enum ResponseChange {
    ReplaceText(ReplaceResponseTextChange),
    InsertText(InsertResponseTextChange),
    RemoveText(RemoveResponseTextChange),
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct RequestTransformCall {
    pub context: HookContext,
    pub request: NeutralRequest,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct LogicalModelForwardCall {
    pub context: HookContext,
    pub input: LogicalModelInput,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MemberRequestTransformCall {
    pub context: HookContext,
    pub request: MemberRequestView,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct RequestObserveCall {
    pub context: HookContext,
    pub original_request: NeutralRequest,
    pub final_member_request: NeutralRequest,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ResponseTransformCall {
    pub context: HookContext,
    pub response: NeutralResponse,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ResponseObserveCall {
    pub context: HookContext,
    pub upstream_response: NeutralResponse,
    pub client_response: NeutralResponse,
    pub stream_ended: bool,
    pub stream_interrupted: bool,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(tag = "kind", content = "value", rename_all = "snake_case")]
pub enum HookInput {
    RequestTransform(RequestTransformCall),
    LogicalModelForward(LogicalModelForwardCall),
    MemberRequestTransform(MemberRequestTransformCall),
    RequestObserve(RequestObserveCall),
    ResponseTransform(ResponseTransformCall),
    ResponseObserve(ResponseObserveCall),
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(tag = "kind", content = "value", rename_all = "snake_case")]
pub enum HookResult {
    Unchanged,
    RequestChanges(Vec<RequestChange>),
    Forward(ForwardDecision),
    MemberChanges(Vec<MemberChange>),
    ResponseChanges(Vec<ResponseChange>),
    Observed,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct HookOutput {
    pub result: HookResult,
    #[serde(with = "crate::optional_bytes")]
    pub opaque_state: Option<Vec<u8>>,
    pub observations: Vec<ObservationEntry>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MediaExportRequest {
    pub media_handle: String,
    pub destination_id: String,
    pub relative_path: Option<String>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MediaExportAccepted {
    pub export_id: String,
}

pub type MediaExportResult = Result<MediaExportAccepted, HostError>;

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ExtismRequestTransformInput {
    pub request: NeutralRequest,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ExtismLogicalModelForwardInput {
    pub input: LogicalModelInput,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ExtismMemberRequestTransformInput {
    pub request: MemberRequestView,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ExtismRequestObserveInput {
    pub original_request: NeutralRequest,
    pub final_member_request: NeutralRequest,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ExtismResponseTransformInput {
    pub response: NeutralResponse,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ExtismResponseObserveInput {
    pub upstream_response: NeutralResponse,
    pub client_response: NeutralResponse,
    pub stream_ended: bool,
    pub stream_interrupted: bool,
}
