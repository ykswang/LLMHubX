# 开发与调试

`generated/level1.d.ts` 与 `wit/` 来自同一份 ABI Level 1 WIT。`runHook` 通过 Hook ID 将 handler 输入绑定到对应业务 input；生成类型使用 Extism `snake_case` wire 字段。

`canonicalJson` 负责 RFC 8785 输出；u64 使用十进制 string，bytes 使用无 padding base64url。只有 Observe Hook 可以调用 `submitMediaExport`。
Host API 失败抛出 `HostApiError`；插件按 `error.code` 判断，`hostMessage` 仅作为可选说明，未知错误码保持原字符串。

运行 `npm test` 完成 WIT 类型再生成与严格 typecheck，运行 `npm run build` 构建最小模板。
