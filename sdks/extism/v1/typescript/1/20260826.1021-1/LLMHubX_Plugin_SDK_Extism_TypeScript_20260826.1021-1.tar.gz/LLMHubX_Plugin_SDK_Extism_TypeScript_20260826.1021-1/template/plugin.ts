import { changes, runHook } from "../src/index.js";

export function llmhubx_member_request_transform(): void {
  runHook("member-request-transform", () =>
    changes([{ kind: "set_reasoning_effort", value: "none" }]),
  );
}
