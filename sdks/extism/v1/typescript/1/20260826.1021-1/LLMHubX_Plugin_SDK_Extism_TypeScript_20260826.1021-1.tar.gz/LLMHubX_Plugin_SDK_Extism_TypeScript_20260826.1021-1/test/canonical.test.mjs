import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { build } from "esbuild";

test("canonical encoder 逐项匹配 Level 1 冻结 fixture", async () => {
  const result = await build({
    entryPoints: [new URL("../src/index.ts", import.meta.url).pathname],
    bundle: true,
    format: "esm",
    platform: "neutral",
    write: false,
  });
  const source = Buffer.from(result.outputFiles[0].contents).toString("base64");
  const module = await import(`data:text/javascript;base64,${source}`);
  const document = JSON.parse(await readFile(
    new URL("../conformance/canonical-fixtures.json", import.meta.url),
    "utf8",
  ));
  assert.ok(document.fixtures.length > 100);
  for (const fixture of document.fixtures) {
    assert.equal(module.canonicalJson(JSON.parse(fixture.input_json)), fixture.canonical_json, fixture.id);
  }

  globalThis.Host = { getFunctions: () => ({ submit_media_export: () => 2 }) };
  globalThis.Memory = {
    fromString: () => ({ offset: 1 }),
    find: () => ({ readJsonObject: () => ({ error: { code: "future_code", message: null } }) }),
  };
  assert.throws(
    () => module.submitMediaExport({ media_handle: "h", destination_id: "d", relative_path: null }),
    (error) => error instanceof module.HostApiError
      && error.code === "future_code"
      && error.hostMessage === null,
  );
  delete globalThis.Host;
  delete globalThis.Memory;
});
