import type {
  ConfigEntry,
  HookId,
  LogicalModelForwardCall,
  MediaExportAccepted,
  MediaExportDestination,
  MediaExportRequest,
  MemberChange,
  MemberRequestTransformCall,
  ObservationEntry,
  RequestChange,
  RequestObserveCall,
  RequestTransformCall,
  ResponseChange,
  ResponseObserveCall,
  ResponseTransformCall,
} from "../generated/level1.js";

export type * from "../generated/level1.js";

export const TARGET_ABI_LEVEL = 1 as const;

export interface HookContext {
  invocation_id: string;
  config: ConfigEntry[];
  opaque_state: string | null;
  media_export_destinations: MediaExportDestination[];
}

type WithoutContext<T> = Omit<T, "context">;

export interface HookInputById {
  "request-transform": WithoutContext<RequestTransformCall>;
  "logical-model-forward": WithoutContext<LogicalModelForwardCall>;
  "member-request-transform": WithoutContext<MemberRequestTransformCall>;
  "request-observe": WithoutContext<RequestObserveCall>;
  "response-transform": WithoutContext<ResponseTransformCall>;
  "response-observe": WithoutContext<ResponseObserveCall>;
}

interface HookEnvelope<K extends HookId> extends HookContext {
  abi_level: number;
  hook: K;
  input: HookInputById[K];
}

export type WireHookResult =
  | { kind: "unchanged" }
  | { kind: "changes"; changes: RequestChange[] | MemberChange[] | ResponseChange[] }
  | { kind: "forward_to"; model_id: string }
  | { kind: "observed" };

export interface WireHookOutput {
  result: WireHookResult;
  opaque_state: string | null;
  observations: ObservationEntry[];
}

export function unchanged(
  observations: ObservationEntry[] = [],
  opaqueState: string | null = null,
): WireHookOutput {
  return { result: { kind: "unchanged" }, opaque_state: opaqueState, observations };
}

export function changes(
  values: RequestChange[] | MemberChange[] | ResponseChange[],
  observations: ObservationEntry[] = [],
  opaqueState: string | null = null,
): WireHookOutput {
  if (values.length === 0) throw new TypeError("changes 必须是非空数组");
  return {
    result: { kind: "changes", changes: values },
    opaque_state: opaqueState,
    observations,
  };
}

export function forwardTo(
  modelId: string,
  observations: ObservationEntry[] = [],
  opaqueState: string | null = null,
): WireHookOutput {
  return {
    result: { kind: "forward_to", model_id: modelId },
    opaque_state: opaqueState,
    observations,
  };
}

export function observed(observations: ObservationEntry[] = []): WireHookOutput {
  return { result: { kind: "observed" }, opaque_state: null, observations };
}

export function runHook<K extends HookId>(
  expectedHook: K,
  handler: (context: HookContext, input: HookInputById[K]) => WireHookOutput,
): void {
  const envelope = JSON.parse(Host.inputString()) as HookEnvelope<K>;
  if (envelope.abi_level !== TARGET_ABI_LEVEL || envelope.hook !== expectedHook) {
    throw new Error("ABI Level 或 Hook 不匹配");
  }
  const keys = new Set(envelope.config.map((entry) => entry.key));
  if (keys.size !== envelope.config.length) throw new TypeError("config 包含重复 key");
  const output = handler(
    {
      invocation_id: envelope.invocation_id,
      config: envelope.config,
      opaque_state: envelope.opaque_state,
      media_export_destinations: envelope.media_export_destinations,
    },
    envelope.input,
  );
  Host.outputString(canonicalJson({
    abi_level: TARGET_ABI_LEVEL,
    hook: expectedHook,
    ...output,
  }));
}

export function submitMediaExport(request: MediaExportRequest): MediaExportAccepted {
  const memory = Memory.fromString(canonicalJson(request));
  const functions = Host.getFunctions() as ReturnType<typeof Host.getFunctions> & {
    submit_media_export(input: PTR): PTR;
  };
  const pointer = functions.submit_media_export(memory.offset);
  const result = Memory.find(pointer).readJsonObject() as
    | { ok: MediaExportAccepted }
    | { error: { code: string; message: string | null } };
  if ("error" in result) throw new HostApiError(result.error);
  return result.ok;
}

export class HostApiError extends Error {
  readonly code: string;
  readonly hostMessage: string | null;

  constructor(error: { code: string; message: string | null }) {
    super(error.message ?? error.code);
    this.name = "HostApiError";
    this.code = error.code;
    this.hostMessage = error.message;
  }
}

export function canonicalJson(value: unknown): string {
  if (value === null) return "null";
  if (typeof value === "string" || typeof value === "boolean") return JSON.stringify(value);
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new TypeError("JSON number 必须是有限值");
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (typeof value === "object") {
    const object = value as Record<string, unknown>;
    return `{${Object.keys(object).sort().map((key) =>
      `${JSON.stringify(key)}:${canonicalJson(object[key])}`).join(",")}}`;
  }
  throw new TypeError("值不能编码为 canonical JSON");
}
