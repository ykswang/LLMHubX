# LLMHubX Extism TypeScript SDK

该 SDK 的 Level 1 wire 类型由冻结 WIT 生成，使用 `snake_case` 字段、`kind/value` variant、十进制字符串 `u64` 和无 padding base64url bytes。

```shell
npm install
npm test
```
