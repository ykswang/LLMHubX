import type {
  ConfigEntry,
  HookId,
  LogicalModelForwardCall,
  MediaExportAccepted,
  MediaExportDestination,
  MediaExportRequest,
  MemberChange,
  MemberRequestTransformCall,
  ObservationEntry,
  RequestChange,
  RequestObserveCall,
  RequestTransformCall,
  ResponseChange,
  ResponseObserveCall,
  ResponseTransformCall,
} from "../generated/level1.js";

export type * from "../generated/level1.js";
export const TARGET_ABI_LEVEL: 1;

export interface HookContext {
  invocation_id: string;
  config: ConfigEntry[];
  opaque_state: string | null;
  media_export_destinations: MediaExportDestination[];
}

export interface HookInputById {
  "request-transform": Omit<RequestTransformCall, "context">;
  "logical-model-forward": Omit<LogicalModelForwardCall, "context">;
  "member-request-transform": Omit<MemberRequestTransformCall, "context">;
  "request-observe": Omit<RequestObserveCall, "context">;
  "response-transform": Omit<ResponseTransformCall, "context">;
  "response-observe": Omit<ResponseObserveCall, "context">;
}

export type WireHookResult =
  | { kind: "unchanged" }
  | { kind: "changes"; changes: RequestChange[] | MemberChange[] | ResponseChange[] }
  | { kind: "forward_to"; model_id: string }
  | { kind: "observed" };

export interface WireHookOutput {
  result: WireHookResult;
  opaque_state: string | null;
  observations: ObservationEntry[];
}

export function unchanged(
  observations?: ObservationEntry[],
  opaqueState?: string | null,
): WireHookOutput;
export function changes(
  values: RequestChange[] | MemberChange[] | ResponseChange[],
  observations?: ObservationEntry[],
  opaqueState?: string | null,
): WireHookOutput;
export function forwardTo(
  modelId: string,
  observations?: ObservationEntry[],
  opaqueState?: string | null,
): WireHookOutput;
export function observed(observations?: ObservationEntry[]): WireHookOutput;
export function runHook<K extends HookId>(
  expectedHook: K,
  handler: (context: HookContext, input: HookInputById[K]) => WireHookOutput,
): void;
export function submitMediaExport(request: MediaExportRequest): MediaExportAccepted;
export class HostApiError extends Error {
  readonly code: string;
  readonly hostMessage: string | null;
}
export function canonicalJson(value: unknown): string;
