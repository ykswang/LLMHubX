import { execFileSync } from "node:child_process";
import { mkdir } from "node:fs/promises";
import { build } from "esbuild";
import { delimiter, dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

await mkdir("dist", { recursive: true });
await build({
  entryPoints: ["template/plugin.js"],
  outfile: "dist/plugin.js",
  bundle: true,
  format: "cjs",
  platform: "neutral",
});
const compiler = execFileSync(process.execPath, ["tools/ensure-extism-js.mjs"], {
  encoding: "utf8",
}).trim();
const sdkRoot = dirname(fileURLToPath(import.meta.url));
const binaryen = join(sdkRoot, "node_modules", "binaryen", "bin");
execFileSync(compiler, ["dist/plugin.js", "-i", "template/plugin.d.ts", "-o", "dist/plugin.raw.wasm"], {
  stdio: "inherit",
  env: { ...process.env, PATH: `${binaryen}${delimiter}${process.env.PATH ?? ""}` },
});
execFileSync(process.execPath, ["tools/sanitize-extism-js-wasm.mjs", "dist/plugin.raw.wasm", "dist/plugin.wasm"], {
  stdio: "inherit",
});
