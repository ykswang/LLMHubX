declare module "extism:host" {
  interface user {
    submit_media_export(input: PTR): PTR;
  }
}

declare module "main" {
  export function llmhubx_member_request_transform(): I32;
}
