// 由 scripts/generate-extism-sdk-types.mjs 从 ABI Level 1 WIT 生成，请勿手工编辑。
/** @module Interface llmhubx:plugin-level-1/types **/
/**
 * @min_abi_level 1
 * # Variants
 *
 * ## `"request-transform"`
 *
 * @min_abi_level 1
 * ## `"logical-model-forward"`
 *
 * @min_abi_level 1
 * ## `"member-request-transform"`
 *
 * @min_abi_level 1
 * ## `"request-observe"`
 *
 * @min_abi_level 1
 * ## `"response-transform"`
 *
 * @min_abi_level 1
 * ## `"response-observe"`
 *
 * @min_abi_level 1
 */
export type HookId = 'request-transform' | 'logical-model-forward' | 'member-request-transform' | 'request-observe' | 'response-transform' | 'response-observe';
/**
 * @min_abi_level 1
 */
export type ImplementedHookList = Array<HookId>;
/**
 * @min_abi_level 1
 */
export type ConfigValue =
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'string_value',
    value: string,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'number_value',
    value: number,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'boolean_value',
    value: boolean,
  };
/**
 * @min_abi_level 1
 */
export interface ConfigEntry {
  /**
   * @min_abi_level 1
   */
  key: string,
  /**
   * @min_abi_level 1
   */
  value: ConfigValue,
}
/**
 * @min_abi_level 1
 */
export type ObservationValue =
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'string_value',
    value: string,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'number_value',
    value: number,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'boolean_value',
    value: boolean,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'string_list',
    value: Array<string>,
  };
/**
 * @min_abi_level 1
 */
export interface ObservationEntry {
  /**
   * @min_abi_level 1
   */
  key: string,
  /**
   * @min_abi_level 1
   */
  value: ObservationValue,
}
/**
 * @min_abi_level 1
 * # Variants
 *
 * ## `"system"`
 *
 * @min_abi_level 1
 * @read_permission request.prompts.read system
 * ## `"user"`
 *
 * @min_abi_level 1
 * @read_permission request.prompts.read user
 */
export type MessageRole = 'system' | 'user';
/**
 * @min_abi_level 1
 * # Variants
 *
 * ## `"request"`
 *
 * @min_abi_level 1
 * ## `"response"`
 *
 * @min_abi_level 1
 */
export type MediaOrigin = 'request' | 'response';
/**
 * @min_abi_level 1
 * # Variants
 *
 * ## `"image"`
 *
 * @min_abi_level 1
 * ## `"audio"`
 *
 * @min_abi_level 1
 * ## `"video"`
 *
 * @min_abi_level 1
 */
export type MediaKind = 'image' | 'audio' | 'video';
/**
 * @min_abi_level 1
 */
export interface MediaMetadata {
  /**
   * @min_abi_level 1
   * @read_permission media.metadata.read request.image
   * @read_permission media.metadata.read request.audio
   * @read_permission media.metadata.read request.video
   * @read_permission media.metadata.read response.image
   * @read_permission media.metadata.read response.audio
   * @read_permission media.metadata.read response.video
   */
  handle: string,
  /**
   * @min_abi_level 1
   */
  origin: MediaOrigin,
  /**
   * @min_abi_level 1
   */
  kind: MediaKind,
  /**
   * @min_abi_level 1
   */
  mime_type: string | null,
  /**
   * @min_abi_level 1
   */
  byte_length: string | null,
  /**
   * @min_abi_level 1
   */
  width: number | null,
  /**
   * @min_abi_level 1
   */
  height: number | null,
  /**
   * @min_abi_level 1
   */
  duration_ms: string | null,
}
/**
 * @min_abi_level 1
 */
export interface PromptTextPart {
  /**
   * @min_abi_level 1
   */
  part_id: string,
  /**
   * @min_abi_level 1
   */
  text: string,
}
/**
 * @min_abi_level 1
 */
export interface PromptMediaPart {
  /**
   * @min_abi_level 1
   */
  part_id: string,
  /**
   * @min_abi_level 1
   */
  media: MediaMetadata,
}
/**
 * @min_abi_level 1
 */
export type PromptPart =
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'text',
    value: PromptTextPart,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'media',
    value: PromptMediaPart,
  };
/**
 * @min_abi_level 1
 */
export interface PromptMessage {
  /**
   * @min_abi_level 1
   */
  message_id: string,
  /**
   * @min_abi_level 1
   */
  role: MessageRole,
  /**
   * @min_abi_level 1
   */
  parts: Array<PromptPart>,
}
/**
 * @min_abi_level 1
 */
export interface HeaderEntry {
  /**
   * @min_abi_level 1
   * @read_permission request.headers.read dynamic
   */
  name: string,
  /**
   * @min_abi_level 1
   */
  value: string,
}
/**
 * @min_abi_level 1
 */
export type InsertionPoint =
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'start',
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'end',
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'before',
    value: string,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'after',
    value: string,
  };
/**
 * @min_abi_level 1
 */
export interface HostError {
  /**
   * @min_abi_level 1
   * @error_code invalid_argument @min_abi_level 1
   * @error_code permission_denied @min_abi_level 1
   * @error_code invalid_handle @min_abi_level 1
   * @error_code invalid_destination @min_abi_level 1
   * @error_code out_of_scope @min_abi_level 1
   * @error_code resource_limit_exceeded @min_abi_level 1
   * @error_code io_failed @min_abi_level 1
   * @error_code internal_error @min_abi_level 1
   */
  code: string,
  /**
   * @min_abi_level 1
   */
  message: string | null,
}
/**
 * @min_abi_level 1
 */
export interface MediaExportDestination {
  /**
   * @min_abi_level 1
   */
  destination_id: string,
  /**
   * @min_abi_level 1
   */
  label: string,
}
/**
 * @min_abi_level 1
 */
export interface HookContext {
  /**
   * @min_abi_level 1
   */
  abi_level: number,
  /**
   * @min_abi_level 1
   */
  invocation_id: string,
  /**
   * @min_abi_level 1
   */
  config: Array<ConfigEntry>,
  /**
   * @min_abi_level 1
   */
  opaque_state: Uint8Array | null,
  /**
   * @min_abi_level 1
   */
  media_export_destinations: Array<MediaExportDestination>,
}
/**
 * @min_abi_level 1
 */
export type OutputKind =
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'text',
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'json_object',
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'json_schema',
    value: string,
  };
/**
 * @min_abi_level 1
 */
export interface SearchOptions {
  /**
   * @min_abi_level 1
   * @read_permission request.parameters.read search.enabled
   */
  enabled: boolean | null,
  /**
   * @min_abi_level 1
   * @read_permission request.parameters.read search.forced
   */
  forced: boolean | null,
  /**
   * @min_abi_level 1
   * @read_permission request.parameters.read search.return_sources
   */
  return_sources: boolean | null,
}
/**
 * @min_abi_level 1
 */
export interface RequestParameters {
  /**
   * @min_abi_level 1
   * @read_permission request.parameters.read temperature
   */
  temperature: number | null,
  /**
   * @min_abi_level 1
   * @read_permission request.parameters.read top_p
   */
  top_p: number | null,
  /**
   * @min_abi_level 1
   * @read_permission request.parameters.read max_output_tokens
   */
  max_output_tokens: string | null,
  /**
   * @min_abi_level 1
   * @read_permission request.parameters.read stop_sequences
   */
  stop_sequences: Array<string> | null,
  /**
   * @min_abi_level 1
   * @read_permission request.parameters.read seed
   */
  seed: string | null,
  /**
   * @min_abi_level 1
   * @read_permission request.parameters.read candidate_count
   */
  candidate_count: number | null,
  /**
   * @min_abi_level 1
   * @read_permission request.parameters.read output
   */
  output: OutputKind | null,
  /**
   * @min_abi_level 1
   */
  search: SearchOptions | null,
  /**
   * @min_abi_level 1
   * @read_permission request.parameters.read store_response
   */
  store_response: boolean | null,
}
/**
 * @min_abi_level 1
 */
export interface NeutralRequest {
  /**
   * @min_abi_level 1
   */
  parameters: RequestParameters,
  /**
   * @min_abi_level 1
   */
  prompts: Array<PromptMessage>,
  /**
   * @min_abi_level 1
   */
  headers: Array<HeaderEntry>,
  /**
   * @min_abi_level 1
   */
  media: Array<MediaMetadata>,
}
/**
 * @min_abi_level 1
 */
export interface ReplacePromptTextChange {
  /**
   * @min_abi_level 1
   */
  message_id: string,
  /**
   * @min_abi_level 1
   */
  part_id: string,
  /**
   * @min_abi_level 1
   */
  text: string,
}
/**
 * @min_abi_level 1
 */
export interface InsertPromptMessageChange {
  /**
   * @min_abi_level 1
   */
  at: InsertionPoint,
  /**
   * @min_abi_level 1
   */
  role: MessageRole,
  /**
   * @min_abi_level 1
   */
  text_parts: Array<string>,
}
/**
 * @min_abi_level 1
 */
export interface RemovePromptMessageChange {
  /**
   * @min_abi_level 1
   */
  message_id: string,
}
/**
 * @min_abi_level 1
 */
export interface SetHeaderChange {
  /**
   * @min_abi_level 1
   */
  name: string,
  /**
   * @min_abi_level 1
   */
  value: string,
}
/**
 * @min_abi_level 1
 */
export interface RemoveHeaderChange {
  /**
   * @min_abi_level 1
   */
  name: string,
}
/**
 * @min_abi_level 1
 */
export type RequestChange =
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write temperature
     */
    kind: 'set_temperature',
    value: number,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write temperature
     */
    kind: 'clear_temperature',
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write top_p
     */
    kind: 'set_top_p',
    value: number,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write top_p
     */
    kind: 'clear_top_p',
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write max_output_tokens
     */
    kind: 'set_max_output_tokens',
    value: string,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write max_output_tokens
     */
    kind: 'clear_max_output_tokens',
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write stop_sequences
     */
    kind: 'set_stop_sequences',
    value: Array<string>,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write stop_sequences
     */
    kind: 'clear_stop_sequences',
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write seed
     */
    kind: 'set_seed',
    value: string,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write seed
     */
    kind: 'clear_seed',
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write candidate_count
     */
    kind: 'set_candidate_count',
    value: number,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write candidate_count
     */
    kind: 'clear_candidate_count',
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write output
     */
    kind: 'set_output',
    value: OutputKind,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write output
     */
    kind: 'clear_output',
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write search.enabled
     * @write_permission request.parameters.write search.forced
     * @write_permission request.parameters.write search.return_sources
     */
    kind: 'set_search',
    value: SearchOptions,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write search.enabled
     * @write_permission request.parameters.write search.forced
     * @write_permission request.parameters.write search.return_sources
     */
    kind: 'clear_search',
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write store_response
     */
    kind: 'set_store_response',
    value: boolean,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.parameters.write store_response
     */
    kind: 'clear_store_response',
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.prompts.write system
     * @write_permission request.prompts.write user
     */
    kind: 'replace_prompt_text',
    value: ReplacePromptTextChange,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.prompts.write system
     * @write_permission request.prompts.write user
     */
    kind: 'insert_prompt_message',
    value: InsertPromptMessageChange,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.prompts.write system
     * @write_permission request.prompts.write user
     */
    kind: 'remove_prompt_message',
    value: RemovePromptMessageChange,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.headers.write dynamic
     */
    kind: 'set_header',
    value: SetHeaderChange,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.headers.write dynamic
     */
    kind: 'remove_header',
    value: RemoveHeaderChange,
  };
/**
 * @min_abi_level 1
 */
export interface ReasoningOptions {
  /**
   * @min_abi_level 1
   * @read_permission request.reasoning.read enabled
   */
  enabled: boolean | null,
  /**
   * @min_abi_level 1
   * @read_permission request.reasoning.read effort
   */
  effort: string | null,
  /**
   * @min_abi_level 1
   * @read_permission request.reasoning.read budget_tokens
   */
  budget_tokens: string | null,
}
/**
 * @min_abi_level 1
 */
export interface TokenRange {
  /**
   * @min_abi_level 1
   */
  minimum: string,
  /**
   * @min_abi_level 1
   */
  maximum: string | null,
}
/**
 * @min_abi_level 1
 */
export interface ReasoningCapabilities {
  /**
   * @min_abi_level 1
   * @read_permission request.reasoning.read enabled
   */
  toggle: boolean,
  /**
   * @min_abi_level 1
   * @read_permission request.reasoning.read effort
   */
  efforts: Array<string>,
  /**
   * @min_abi_level 1
   * @read_permission request.reasoning.read budget_tokens
   */
  budget_tokens: TokenRange | null,
}
/**
 * @min_abi_level 1
 */
export interface MemberRequestView {
  /**
   * @min_abi_level 1
   */
  reasoning: ReasoningOptions,
  /**
   * @min_abi_level 1
   */
  capabilities: ReasoningCapabilities,
}
/**
 * @min_abi_level 1
 */
export type MemberChange =
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.reasoning.write enabled
     */
    kind: 'set_reasoning_enabled',
    value: boolean,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.reasoning.write enabled
     */
    kind: 'clear_reasoning_enabled',
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.reasoning.write effort
     */
    kind: 'set_reasoning_effort',
    value: string,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.reasoning.write effort
     */
    kind: 'clear_reasoning_effort',
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.reasoning.write budget_tokens
     */
    kind: 'set_reasoning_budget_tokens',
    value: string,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission request.reasoning.write budget_tokens
     */
    kind: 'clear_reasoning_budget_tokens',
  };
/**
 * @min_abi_level 1
 */
export interface LogicalModelView {
  /**
   * @min_abi_level 1
   * @read_permission logical-model.forward dynamic
   */
  model_id: string,
  /**
   * @min_abi_level 1
   */
  enabled: boolean,
  /**
   * @min_abi_level 1
   */
  protocols: Array<string>,
  /**
   * @min_abi_level 1
   */
  capability_ids: Array<string>,
}
/**
 * @min_abi_level 1
 */
export interface LogicalModelInput {
  /**
   * @min_abi_level 1
   */
  current_model_id: string,
  /**
   * @min_abi_level 1
   */
  models: Array<LogicalModelView>,
  /**
   * @min_abi_level 1
   */
  request: NeutralRequest,
}
/**
 * @min_abi_level 1
 */
export type ForwardDecision =
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'unchanged',
  }
  | {
    /**
     * @min_abi_level 1
     * @requires_permission logical-model.forward dynamic
     */
    kind: 'forward_to',
    value: string,
  };
/**
 * @min_abi_level 1
 * # Variants
 *
 * ## `"thinking"`
 *
 * @min_abi_level 1
 * @read_permission response.thinking.read -
 * ## `"content"`
 *
 * @min_abi_level 1
 * @read_permission response.content.read -
 */
export type ResponseChannel = 'thinking' | 'content';
/**
 * @min_abi_level 1
 */
export interface ResponseTextPart {
  /**
   * @min_abi_level 1
   */
  part_id: string,
  /**
   * @min_abi_level 1
   */
  channel: ResponseChannel,
  /**
   * @min_abi_level 1
   */
  text: string,
}
/**
 * @min_abi_level 1
 */
export interface NeutralResponse {
  /**
   * @min_abi_level 1
   */
  streaming: boolean,
  /**
   * @min_abi_level 1
   */
  text_parts: Array<ResponseTextPart>,
  /**
   * @min_abi_level 1
   */
  media: Array<MediaMetadata>,
}
/**
 * @min_abi_level 1
 */
export interface ReplaceResponseTextChange {
  /**
   * @min_abi_level 1
   */
  part_id: string,
  /**
   * @min_abi_level 1
   */
  text: string,
}
/**
 * @min_abi_level 1
 */
export interface InsertResponseTextChange {
  /**
   * @min_abi_level 1
   */
  channel: ResponseChannel,
  /**
   * @min_abi_level 1
   */
  at: InsertionPoint,
  /**
   * @min_abi_level 1
   */
  text: string,
}
/**
 * @min_abi_level 1
 */
export interface RemoveResponseTextChange {
  /**
   * @min_abi_level 1
   */
  part_id: string,
}
/**
 * @min_abi_level 1
 */
export type ResponseChange =
  | {
    /**
     * @min_abi_level 1
     * @write_permission response.thinking.write -
     * @write_permission response.content.write -
     */
    kind: 'replace_text',
    value: ReplaceResponseTextChange,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission response.thinking.write -
     * @write_permission response.content.write -
     */
    kind: 'insert_text',
    value: InsertResponseTextChange,
  }
  | {
    /**
     * @min_abi_level 1
     * @write_permission response.thinking.write -
     * @write_permission response.content.write -
     */
    kind: 'remove_text',
    value: RemoveResponseTextChange,
  };
/**
 * @min_abi_level 1
 */
export interface RequestTransformCall {
  /**
   * @min_abi_level 1
   */
  context: HookContext,
  /**
   * @min_abi_level 1
   */
  request: NeutralRequest,
}
/**
 * @min_abi_level 1
 */
export interface LogicalModelForwardCall {
  /**
   * @min_abi_level 1
   */
  context: HookContext,
  /**
   * @min_abi_level 1
   */
  input: LogicalModelInput,
}
/**
 * @min_abi_level 1
 */
export interface MemberRequestTransformCall {
  /**
   * @min_abi_level 1
   */
  context: HookContext,
  /**
   * @min_abi_level 1
   */
  request: MemberRequestView,
}
/**
 * @min_abi_level 1
 */
export interface RequestObserveCall {
  /**
   * @min_abi_level 1
   */
  context: HookContext,
  /**
   * @min_abi_level 1
   */
  original_request: NeutralRequest,
  /**
   * @min_abi_level 1
   */
  final_member_request: NeutralRequest,
}
/**
 * @min_abi_level 1
 */
export interface ResponseTransformCall {
  /**
   * @min_abi_level 1
   */
  context: HookContext,
  /**
   * @min_abi_level 1
   */
  response: NeutralResponse,
}
/**
 * @min_abi_level 1
 */
export interface ResponseObserveCall {
  /**
   * @min_abi_level 1
   */
  context: HookContext,
  /**
   * @min_abi_level 1
   */
  upstream_response: NeutralResponse,
  /**
   * @min_abi_level 1
   */
  client_response: NeutralResponse,
  /**
   * @min_abi_level 1
   */
  stream_ended: boolean,
  /**
   * @min_abi_level 1
   */
  stream_interrupted: boolean,
}
/**
 * @min_abi_level 1
 */
export type HookInput =
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'request_transform',
    value: RequestTransformCall,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'logical_model_forward',
    value: LogicalModelForwardCall,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'member_request_transform',
    value: MemberRequestTransformCall,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'request_observe',
    value: RequestObserveCall,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'response_transform',
    value: ResponseTransformCall,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'response_observe',
    value: ResponseObserveCall,
  };
/**
 * @min_abi_level 1
 */
export type HookResult =
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'unchanged',
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'request_changes',
    value: Array<RequestChange>,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'forward',
    value: ForwardDecision,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'member_changes',
    value: Array<MemberChange>,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'response_changes',
    value: Array<ResponseChange>,
  }
  | {
    /**
     * @min_abi_level 1
     */
    kind: 'observed',
  };
/**
 * @min_abi_level 1
 */
export interface HookOutput {
  /**
   * @min_abi_level 1
   */
  result: HookResult,
  /**
   * @min_abi_level 1
   */
  opaque_state: Uint8Array | null,
  /**
   * @min_abi_level 1
   * @write_permission observation.annotate -
   */
  observations: Array<ObservationEntry>,
}
/**
 * @min_abi_level 1
 */
export interface MediaExportRequest {
  /**
   * @min_abi_level 1
   */
  media_handle: string,
  /**
   * @min_abi_level 1
   */
  destination_id: string,
  /**
   * @min_abi_level 1
   */
  relative_path: string | null,
}
/**
 * @min_abi_level 1
 */
export interface MediaExportAccepted {
  /**
   * @min_abi_level 1
   */
  export_id: string,
}
/**
 * @min_abi_level 1
 */
export type MediaExportResult = Result<MediaExportAccepted, HostError>;
export type Result<T, E> = { kind: 'ok', value: T } | { kind: 'err', value: E };
