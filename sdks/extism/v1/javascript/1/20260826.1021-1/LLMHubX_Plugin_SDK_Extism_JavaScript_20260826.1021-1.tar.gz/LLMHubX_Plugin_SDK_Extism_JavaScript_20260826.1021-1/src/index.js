export const TARGET_ABI_LEVEL = 1;

export function runHook(expectedHook, handler) {
  const envelope = JSON.parse(Host.inputString());
  if (envelope.abi_level !== TARGET_ABI_LEVEL || envelope.hook !== expectedHook) {
    throw new Error("ABI Level 或 Hook 不匹配");
  }
  assertUniqueEntries(envelope.config, "config");
  const result = handler(
    {
      invocation_id: envelope.invocation_id,
      config: envelope.config,
      opaque_state: envelope.opaque_state,
      media_export_destinations: envelope.media_export_destinations,
    },
    envelope.input,
  );
  Host.outputString(canonicalJson({
    abi_level: TARGET_ABI_LEVEL,
    hook: expectedHook,
    result: result.result,
    opaque_state: result.opaque_state ?? null,
    observations: result.observations ?? [],
  }));
}

export function unchanged(observations = [], opaqueState = null) {
  return { result: { kind: "unchanged" }, opaque_state: opaqueState, observations };
}

export function changes(values, observations = [], opaqueState = null) {
  if (!Array.isArray(values) || values.length === 0) {
    throw new TypeError("changes 必须是非空数组");
  }
  return {
    result: { kind: "changes", changes: values },
    opaque_state: opaqueState,
    observations,
  };
}

export function forwardTo(modelId, observations = [], opaqueState = null) {
  return {
    result: { kind: "forward_to", model_id: modelId },
    opaque_state: opaqueState,
    observations,
  };
}

export function observed(observations = []) {
  return { result: { kind: "observed" }, opaque_state: null, observations };
}

export function submitMediaExport(request) {
  const memory = Memory.fromString(canonicalJson(request));
  const pointer = Host.getFunctions().submit_media_export(memory.offset);
  const result = Memory.find(pointer).readJsonObject();
  if (result && typeof result === "object" && "error" in result) {
    throw new HostApiError(result.error);
  }
  if (!result || typeof result !== "object" || !("ok" in result)) {
    throw new HostApiError({ code: "internal_error", message: null });
  }
  return result.ok;
}

export class HostApiError extends Error {
  constructor(error) {
    const code = typeof error?.code === "string" ? error.code : "internal_error";
    const hostMessage = typeof error?.message === "string" ? error.message : null;
    super(hostMessage ?? code);
    this.name = "HostApiError";
    this.code = code;
    this.hostMessage = hostMessage;
  }
}

export function canonicalJson(value) {
  if (value === null) return "null";
  if (typeof value === "string" || typeof value === "boolean") return JSON.stringify(value);
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new TypeError("JSON number 必须是有限值");
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (typeof value === "object") {
    return `{${Object.keys(value).sort().map((key) =>
      `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`;
  }
  throw new TypeError("值不能编码为 canonical JSON");
}

function assertUniqueEntries(entries, name) {
  if (!Array.isArray(entries)) throw new TypeError(`${name} 必须是数组`);
  const keys = new Set();
  for (const entry of entries) {
    if (!entry || typeof entry.key !== "string" || keys.has(entry.key)) {
      throw new TypeError(`${name} 包含无效或重复 key`);
    }
    keys.add(entry.key);
  }
}
