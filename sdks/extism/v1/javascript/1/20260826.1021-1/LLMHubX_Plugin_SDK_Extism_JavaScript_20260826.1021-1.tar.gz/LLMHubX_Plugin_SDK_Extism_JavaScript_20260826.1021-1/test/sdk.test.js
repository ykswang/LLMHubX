import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import {
  HostApiError,
  canonicalJson,
  changes,
  forwardTo,
  observed,
  submitMediaExport,
  unchanged,
} from "../src/index.js";

test("构造 Level 1 固定结果", () => {
  assert.deepEqual(unchanged(), {
    result: { kind: "unchanged" },
    opaque_state: null,
    observations: [],
  });
  assert.equal(changes([{ kind: "clear_seed" }]).result.kind, "changes");
  assert.equal(observed().result.kind, "observed");
  assert.equal(forwardTo("model-b").result.model_id, "model-b");
  assert.throws(() => changes([]), /非空数组/);
});

test("canonical JSON 使用 JCS key 顺序、零和有限 number 规则", () => {
  assert.equal(canonicalJson({ z: -0, a: "\b\n" }), String.raw`{"a":"\b\n","z":0}`);
  assert.throws(() => canonicalJson(Number.POSITIVE_INFINITY), /有限值/);
});

test("canonical encoder 逐项匹配 Level 1 冻结 fixture", async () => {
  const document = JSON.parse(await readFile(
    new URL("../conformance/canonical-fixtures.json", import.meta.url),
    "utf8",
  ));
  assert.ok(document.fixtures.length > 100);
  for (const fixture of document.fixtures) {
    assert.equal(canonicalJson(JSON.parse(fixture.input_json)), fixture.canonical_json, fixture.id);
  }
});

test("Host API 保留稳定和未知错误码及可选说明", () => {
  globalThis.Host = { getFunctions: () => ({ submit_media_export: () => 2 }) };
  globalThis.Memory = {
    fromString: () => ({ offset: 1 }),
    find: () => ({ readJsonObject: () => ({ error: { code: "future_code", message: "detail" } }) }),
  };
  assert.throws(
    () => submitMediaExport({ media_handle: "h", destination_id: "d", relative_path: null }),
    (error) => error instanceof HostApiError
      && error.code === "future_code"
      && error.hostMessage === "detail",
  );
  globalThis.Memory.find = () => ({ readJsonObject: () => ({ ok: { export_id: "export" } }) });
  assert.deepEqual(
    submitMediaExport({ media_handle: "h", destination_id: "d", relative_path: null }),
    { export_id: "export" },
  );
  delete globalThis.Host;
  delete globalThis.Memory;
});
