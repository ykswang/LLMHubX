import { execFileSync } from "node:child_process";
import { readFile, rm, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const input = process.argv[2];
const output = process.argv[3];
if (!input || !output) throw new Error("用法：sanitize-extism-js-wasm.mjs INPUT OUTPUT");

const sdkRoot = dirname(dirname(fileURLToPath(import.meta.url)));
const binaryen = join(sdkRoot, "node_modules", "binaryen", "bin");
const wasmDis = join(binaryen, "wasm-dis");
const wasmAs = join(binaryen, "wasm-as");
const temporary = `${output}.sanitizing.wat`;

execFileSync(wasmDis, [input, "-o", temporary]);
const source = await readFile(temporary, "utf8");
let customHostImportCount = 0;
let wasiImportCount = 0;
const stubs = [];
const lines = source.split("\n").flatMap((line) => {
  if (line.startsWith(' (import "extism:host/user" "submit_media_export"')) {
    customHostImportCount += 1;
    return [line.replace('"extism:host/user"', '"llmhubx"')];
  }
  const match = line.match(
    /^ \(import "wasi_snapshot_preview1" "([^"]+)" \(func (\$[^ ]+)(.*)\)\)$/,
  );
  if (!match) return [line];
  wasiImportCount += 1;
  const [, name, functionName, signature] = match;
  stubs.push(` (func ${functionName}${signature}${wasiBody(name)})`);
  return [];
});
const lastImport = lines.reduce(
  (latest, line, index) => (line.startsWith(" (import ") ? index : latest),
  -1,
);
lines.splice(lastImport + 1, 0, ...stubs);
const sanitized = lines.join("\n");

if (customHostImportCount !== 1) {
  throw new Error(`submit_media_export import 数量应为 1，实际为 ${customHostImportCount}`);
}
if (wasiImportCount === 0 || sanitized.includes('(import "wasi_snapshot_preview1"')) {
  throw new Error("未能完整内化 Extism JS PDK 的 WASI imports");
}
await writeFile(temporary, sanitized);
try {
  execFileSync(wasmAs, [temporary, "-o", output, "--all-features"], { stdio: "inherit" });
} finally {
  await rm(temporary, { force: true });
}

function wasiBody(name) {
  switch (name) {
    case "random_get":
      return " (memory.fill (local.get 0) (i32.const 0) (local.get 1)) (i32.const 0)";
    case "environ_sizes_get":
      return " (i32.store (local.get 0) (i32.const 0)) (i32.store (local.get 1) (i32.const 0)) (i32.const 0)";
    case "environ_get":
    case "clock_time_get":
    case "fd_close":
    case "fd_fdstat_get":
    case "fd_prestat_get":
    case "fd_prestat_dir_name":
    case "fd_read":
    case "fd_seek":
    case "fd_write":
      return " (i32.const 52)";
    case "proc_exit":
      return " (unreachable)";
    default:
      throw new Error(`Extism JS PDK 出现未冻结的 WASI import：${name}`);
  }
}
