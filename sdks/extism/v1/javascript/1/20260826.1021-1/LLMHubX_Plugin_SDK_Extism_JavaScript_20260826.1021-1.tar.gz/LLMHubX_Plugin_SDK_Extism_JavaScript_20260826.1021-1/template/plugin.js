import { changes, runHook } from "../src/index.js";

export function llmhubx_member_request_transform() {
  runHook("member-request-transform", (_context, input) =>
    changes([{ kind: "set_reasoning_effort", value: "none" }]),
  );
}
