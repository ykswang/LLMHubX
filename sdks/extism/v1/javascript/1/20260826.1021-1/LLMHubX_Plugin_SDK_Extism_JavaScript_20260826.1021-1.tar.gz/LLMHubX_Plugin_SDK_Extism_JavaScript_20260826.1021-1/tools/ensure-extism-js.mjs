import { createHash } from "node:crypto";
import { chmod, mkdir, readFile, writeFile } from "node:fs/promises";
import { gunzipSync } from "node:zlib";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const VERSION = "1.7.0";
const sdkRoot = dirname(dirname(fileURLToPath(import.meta.url)));
const platform = process.platform === "darwin" ? "macos" : process.platform;
const arch = process.arch === "arm64" ? "aarch64" : process.arch;
if (!(["macos", "linux"].includes(platform) && ["aarch64", "x64"].includes(arch))) {
  throw new Error(`Extism JS 编译器暂不支持当前平台：${process.platform}/${process.arch}`);
}
const releaseArch = arch === "x64" ? "x86_64" : arch;
const name = `extism-js-${releaseArch}-${platform}-v${VERSION}.gz`;
const base = `https://github.com/extism/js-pdk/releases/download/v${VERSION}`;
const binary = join(sdkRoot, ".tools", `extism-js-${VERSION}-${releaseArch}-${platform}`);

if (!(await readFile(binary).catch(() => null))) {
  const [archiveResponse, checksumResponse] = await Promise.all([
    fetch(`${base}/${name}`),
    fetch(`${base}/${name}.sha256`),
  ]);
  if (!archiveResponse.ok || !checksumResponse.ok) {
    throw new Error("无法下载 Extism JS 官方编译器及校验值");
  }
  const archive = Buffer.from(await archiveResponse.arrayBuffer());
  const expected = (await checksumResponse.text()).trim();
  const actual = createHash("sha256").update(archive).digest("hex");
  if (!/^[0-9a-f]{64}$/.test(expected) || actual !== expected) {
    throw new Error("Extism JS 编译器 SHA-256 不匹配");
  }
  await mkdir(dirname(binary), { recursive: true });
  await writeFile(binary, gunzipSync(archive));
  await chmod(binary, 0o755);
}
process.stdout.write(binary);
