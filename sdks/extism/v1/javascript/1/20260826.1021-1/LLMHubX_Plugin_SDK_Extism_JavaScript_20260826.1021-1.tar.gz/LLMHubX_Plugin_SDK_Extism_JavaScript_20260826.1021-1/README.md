# LLMHubX Extism JavaScript SDK

该 SDK 绑定 ABI Level 1 的 Extism UTF-8 JSON wire。`generated/level1.d.ts` 从冻结 WIT 生成，模板使用固定 Hook export，不启用 WASI。

```shell
npm install
npm test
npm run build
```

`build` 使用 Extism 官方 `extism-js v1.7.0` 发布产物并校验官方 SHA-256。上游 QuickJS shim 默认产生 WASI imports；SDK 打包步骤把冻结集合内化为确定性、无外部能力的实现，并把自定义 Host import 规范化到 `llmhubx/submit_media_export`。出现未冻结 import 时构建失败。
