# LLMHubX Plugin ABI Level 2

ABI Level 2 在冻结的 Level 1 `plugin` world 之外增加 `workflow-contributions` world，用于声明 `agent.workflow` 与 Expert Agent contribution。

Level 2 Component 必须同时导出：

- Level 1 `plugin` world；
- Level 2 `workflow-contributions` world。

Manifest 中的 Workflow、Focus 或 Expert 字段只能由 `target_abi_level = 2` 的 Bundle 声明。Host 会分别校验 Level 1 Agent/Context declarations 与 Level 2 Workflow/Expert declarations，二者都必须与 Manifest 完全一致。

角色 system protocol 与 AGENT.md 仍作为 Bundle asset 提供。WIT 只声明 contribution 身份、schema revision 和 contract version；Task 状态写回通过 Kernel-owned Task Tool Runtime 完成，不向 CMW 插件开放数据库或队列写入。
