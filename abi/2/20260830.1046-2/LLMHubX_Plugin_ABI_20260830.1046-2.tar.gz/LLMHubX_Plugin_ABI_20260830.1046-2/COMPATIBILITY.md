# ABI Level 2 兼容说明

当前 App 的兼容区间是 `[1, 2]`：

```text
app.min_abi_level <= plugin.target_abi_level <= app.current_abi_level
```

- Level 1 Bundle 继续只实现并加载冻结的 `plugin` world。
- Level 2 Bundle 必须实现 Level 1 基础 world 与 Level 2 Workflow contribution world。
- Level 1 Bundle 不能在 Manifest 中声明 Workflow、Focus 或 Expert 字段。
- Host 不把 Level 2 export 缺失降级为 Level 1，也不从自然语言推断 contribution。
