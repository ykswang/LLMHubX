# LLMHubX Plugin ABI Level 1

本文件由 `scripts/generate-plugin-abi.mjs` 从冻结 WIT 生成，请勿手工编辑。

## Hook

- `request-transform`
- `logical-model-forward`
- `member-request-transform`
- `request-observe`
- `response-transform`
- `response-observe`

## 权限矩阵

| 权限 ID | 规范资源 ID |
|---|---|
| `request.parameters.read` | `temperature`, `top_p`, `max_output_tokens`, `stop_sequences`, `seed`, `candidate_count`, `output`, `search.enabled`, `search.forced`, `search.return_sources`, `store_response` |
| `request.parameters.write` | `temperature`, `top_p`, `max_output_tokens`, `stop_sequences`, `seed`, `candidate_count`, `output`, `search.enabled`, `search.forced`, `search.return_sources`, `store_response` |
| `request.prompts.read` | `system`, `user` |
| `request.prompts.write` | `system`, `user` |
| `request.headers.read` | `dynamic` |
| `request.headers.write` | `dynamic` |
| `request.reasoning.read` | `enabled`, `effort`, `budget_tokens` |
| `request.reasoning.write` | `enabled`, `effort`, `budget_tokens` |
| `response.thinking.read` | `-` |
| `response.thinking.write` | `-` |
| `response.content.read` | `-` |
| `response.content.write` | `-` |
| `logical-model.forward` | `dynamic` |
| `media.metadata.read` | `request.image`, `request.audio`, `request.video`, `response.image`, `response.audio`, `response.video` |
| `media.export` | `request.image`, `request.audio`, `request.video`, `response.image`, `response.audio`, `response.video` |
| `observation.annotate` | `-` |
| `resource.kv.read` | `-` |
| `resource.kv.write` | `-` |
| `resource.relational.read` | `-` |
| `resource.relational.write` | `-` |
| `resource.relational.schema` | `-` |
| `resource.provider.workspace` | `-` |

## Host error code

- `invalid_argument`
- `permission_denied`
- `invalid_handle`
- `invalid_destination`
- `out_of_scope`
- `resource_limit_exceeded`
- `io_failed`
- `internal_error`
- `invalid-argument`
- `permission-denied`
- `not-found`
- `already-exists`
- `type-mismatch`
- `constraint-violation`
- `limit-exceeded`
- `provider-unavailable`
- `internal`

## Canonical conformance

`generated/canonical-fixtures.json` 从本 Level 的全部公开类型生成，冻结整数、bytes、option、list、result、Unicode/control string 和 number 边界。Host 与 CMW Rust SDK 必须逐项得到相同结果。

## WIT SHA-256

- `package.wit`: `7edb1158e863fbfcf36ecb6ff86a8190f85e6c00b23d40be22316d9f2c65bc8f`
- `types.wit`: `38f3efb8b839e023e4cf1df0cdd9017dbf693c092c8756e541dc8506a9140410`
- `hooks.wit`: `16bb3080a58fa1bc196c30d533757f1f19f116ec7889eb31b4b4975c6611bd21`
- `host.wit`: `52878445367cb55ead9bf95909b2dfaec9d87355ef565917ad83449fa28fe530`
- `resource-common.wit`: `dbbb1c602a282a9e31922a2e80409bc8382caa9111ab0d7ebd650dd8c8da7cb3`
- `resource-kv.wit`: `3bba9f5cafc0f93395568f2cde33ffb9496894e09235d0e383597884c792b111`
- `resource-relational-schema.wit`: `e47e5bbc78c07cda4173812507e175762e1efa315ece959af3e9642322e090e6`
- `resource-relational-query.wit`: `ae165294f3ccad803501715132930d074200bd93be765fe6ce8cba3f9f284a8b`
- `resource-dispatch.wit`: `3b4c8d41539798d48f96c7159b2409e76592c10de1cbef7325c535ec650f8cdc`
- `world.wit`: `8c1dd1599535f1856b405795b350fd1ddc8e5331e2cb97f21e3aea3eb4c0b7e9`

公开声明数量：481。
