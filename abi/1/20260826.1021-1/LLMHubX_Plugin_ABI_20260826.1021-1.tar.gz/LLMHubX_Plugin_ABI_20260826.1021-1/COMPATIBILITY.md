# ABI Level 1 兼容说明

ABI Level 1 是 LLMHubX Plugin ABI 的首个正式 Level，没有更早的整数 ABI Level 可兼容。

插件仅在以下条件成立时加载：

```text
app.min_abi_level <= plugin.target_abi_level <= app.current_abi_level
```

当前 App 的兼容区间是 `[1, 1]`。旧格式 `api_version = "1.0.0"` 不映射为 ABI Level 1。

本目录的 WIT 快照一经发布不可修改语义。除纯文档修正外，任何 WIT 变化都必须创建更高 ABI Level。
