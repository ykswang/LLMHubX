# LLMHubX Plugin ABI Level 1

本文件由 `scripts/generate-plugin-abi.mjs` 从冻结 WIT 生成，请勿手工编辑。

## Hook

- `request-transform`
- `logical-model-forward`
- `member-request-transform`
- `request-observe`
- `response-transform`
- `response-observe`

## 权限矩阵

| 权限 ID | 规范资源 ID |
|---|---|
| `request.parameters.read` | `temperature`, `top_p`, `max_output_tokens`, `stop_sequences`, `seed`, `candidate_count`, `output`, `search.enabled`, `search.forced`, `search.return_sources`, `store_response` |
| `request.parameters.write` | `temperature`, `top_p`, `max_output_tokens`, `stop_sequences`, `seed`, `candidate_count`, `output`, `search.enabled`, `search.forced`, `search.return_sources`, `store_response` |
| `request.prompts.read` | `system`, `user` |
| `request.prompts.write` | `system`, `user` |
| `request.headers.read` | `dynamic` |
| `request.headers.write` | `dynamic` |
| `request.reasoning.read` | `enabled`, `effort`, `budget_tokens` |
| `request.reasoning.write` | `enabled`, `effort`, `budget_tokens` |
| `response.thinking.read` | `-` |
| `response.thinking.write` | `-` |
| `response.content.read` | `-` |
| `response.content.write` | `-` |
| `logical-model.forward` | `dynamic` |
| `media.metadata.read` | `request.image`, `request.audio`, `request.video`, `response.image`, `response.audio`, `response.video` |
| `media.export` | `request.image`, `request.audio`, `request.video`, `response.image`, `response.audio`, `response.video` |
| `observation.annotate` | `-` |

## Host error code

- `invalid_argument`
- `permission_denied`
- `invalid_handle`
- `invalid_destination`
- `out_of_scope`
- `resource_limit_exceeded`
- `io_failed`
- `internal_error`

## Canonical JSON conformance

`generated/canonical-fixtures.json` 从本 Level 的全部公开类型生成，冻结 Extism JSON 映射、JCS bytes、整数、bytes、option、list、result、Unicode/control string 和 number 边界。Host 与四套 SDK 必须逐项得到相同 bytes。

## WIT SHA-256

- `package.wit`: `7edb1158e863fbfcf36ecb6ff86a8190f85e6c00b23d40be22316d9f2c65bc8f`
- `types.wit`: `38f3efb8b839e023e4cf1df0cdd9017dbf693c092c8756e541dc8506a9140410`
- `hooks.wit`: `16bb3080a58fa1bc196c30d533757f1f19f116ec7889eb31b4b4975c6611bd21`
- `host.wit`: `17f372614ec12f124342c34daf4eedd5955d091e0fcc58f5af8fcf5f84919b18`
- `world.wit`: `53d7572d554b8abe07b95b0f7c698a22c36514d3e1dbcb994ec2b09eb8ba8e36`

公开声明数量：247。
